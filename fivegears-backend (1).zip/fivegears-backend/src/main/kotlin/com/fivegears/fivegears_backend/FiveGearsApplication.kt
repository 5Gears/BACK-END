package com.fivegears.fivegears_backend

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class FiveGearsApplication

fun main(args: Array<String>) {
	runApplication<FiveGearsApplication>(*args)
}
